# Demo Hello Module v1.0.0
# A simple module for testing the Terraform registry

variable "name" {
  description = "Name to say hello to"
  type        = string
  default     = "World"
}

output "greeting" {
  description = "The greeting message"
  value       = "Hello, ${var.name}!"
}
