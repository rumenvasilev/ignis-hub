# Hello Module

A simple demonstration module for the Terraform registry.

## Usage

```hcl
module "hello" {
  source  = "registry.example.com/demo/hello/aws"
  version = "1.0.0"

  name = "Terraform"
}
```

## Outputs

- `greeting` - Basic greeting message
- `full_greeting` - Greeting with optional prefix
