# Additional variables for the module
variable "prefix" {
  description = "Optional prefix for the greeting"
  type        = string
  default     = ""
}
