output "full_greeting" {
  description = "Full greeting with optional prefix"
  value       = "${var.prefix}${var.prefix != "" ? " " : ""}Hello, ${var.name}!"
}
