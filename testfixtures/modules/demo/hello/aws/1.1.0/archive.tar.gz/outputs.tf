output "full_greeting" {
  description = "Full greeting with optional prefix and suffix"
  value       = "${var.prefix}${var.prefix != "" ? " " : ""}Hello, ${var.name}!${var.suffix != "" ? " " : ""}${var.suffix}"
}

output "version" {
  description = "Module version"
  value       = "1.1.0"
}
