# Demo Hello Module v1.1.0
# A simple module for testing the Terraform registry

variable "name" {
  description = "Name to say hello to"
  type        = string
  default     = "World"
}

variable "uppercase" {
  description = "Whether to uppercase the greeting"
  type        = bool
  default     = false
}

locals {
  greeting = "Hello, ${var.name}!"
}

output "greeting" {
  description = "The greeting message"
  value       = var.uppercase ? upper(local.greeting) : local.greeting
}
