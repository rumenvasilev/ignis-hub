# Additional variables for the module
variable "prefix" {
  description = "Optional prefix for the greeting"
  type        = string
  default     = ""
}

variable "suffix" {
  description = "Optional suffix for the greeting"
  type        = string
  default     = ""
}
