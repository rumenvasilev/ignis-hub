# Hello Module

A simple demonstration module for the Terraform registry.

## Version 1.1.0 Changes

- Added `uppercase` variable to optionally uppercase the greeting
- Added `suffix` variable for additional customization
- Added `version` output

## Usage

```hcl
module "hello" {
  source  = "registry.example.com/demo/hello/aws"
  version = "1.1.0"

  name      = "Terraform"
  uppercase = true
}
```
